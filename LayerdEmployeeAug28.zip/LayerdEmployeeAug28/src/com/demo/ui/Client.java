package com.demo.ui;

import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

import com.demo.model.Employee;
import com.demo.service.EmployeeService;
import com.demo.service.EmployeeServiceImpl;

public class Client {

	public static void main(String[] args) {

		// object createion of service layer
		EmployeeService service = new EmployeeServiceImpl();

		while (true) {
			System.out.println("***Employee management Application*******");
			System.out.println("1.Add Employee");
			System.out.println("2.update Employee");
			System.out.println("3.get Employee");
			System.out.println("4.delete Employee");
			System.out.println("5.Get All Employees");

			Scanner sc = new Scanner(System.in);
			int option = sc.nextInt();

			switch (option) {
			case 1:
				System.out.println("Enter Employee details to insert");
				System.out.println("ENTER Emplyee name");
				String empName=sc.next();
				System.out.println("Enter Employee salary");
				int empSal=sc.nextInt();
				System.out.println("Enter EMployee Adfdress");
				String empAdd=sc.next();
				System.out.println("Enter Eployee empaid");
				String empMail=sc.next();
				
				//create object of employee class 
				Employee emp= new Employee(empName, empSal, empAdd, empMail);
				
				//service layer add employee
				int empid=service.addEmployee(emp);
				System.out.println("Employee added suufully :"+empid);
				
				break;
			case 2:
				System.out.println("Enter Employee id to update");
				int eid=sc.nextInt();
				System.out.println("ENTER Emplyee name");
				String ename=sc.next();
				System.out.println("Enter Employee salary");
				int eSal=sc.nextInt();
				System.out.println("Enter EMployee Adfdress");
				String eAdd=sc.next();
				System.out.println("Enter Eployee empaid");
				String eMail=sc.next();
				
				Employee emp1= new Employee(ename, eSal, eAdd, eMail);
				
				Employee eo=service.updateEmployee(eid, emp1);
				
				System.out.println("Employee updadted syuufully :"+eid);
				break;
			case 3:
				System.out.println("Enter EMPLOYEE ID TO GET");
				int eid1=sc.nextInt();
				
				Employee emon=service.getEmployee(eid1);
				System.out.println(emon);
				break;
			case 4:
				System.out.println("Enter EMPLOYEE ID TO DELETE");
				int eid2=sc.nextInt();
				
				service.deleteEmployee(eid2);
				System.out.println("employee deleted :"+eid2);
				break;
			case 5:
				Set<Entry<Integer, Employee>> itr=service.getAllEmployees();
				Iterator<Entry<Integer,Employee>> res=itr.iterator();
				while(res.hasNext())
				{
					Entry<Integer,Employee> finalResult=res.next();
					System.out.println(finalResult.getKey()+" "+finalResult.getValue());
				}
				break;
			default:
				System.out.println("no input matched");
				break;
			}

		}
	}
}

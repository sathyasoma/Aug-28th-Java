package com.demo.model;

public class Employee {

	private String empname;
	private int empsal;
	private String empadd;
	private String empMail;
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public int getEmpsal() {
		return empsal;
	}
	public void setEmpsal(int empsal) {
		this.empsal = empsal;
	}
	public String getEmpadd() {
		return empadd;
	}
	public void setEmpadd(String empadd) {
		this.empadd = empadd;
	}
	public String getEmpMail() {
		return empMail;
	}
	public void setEmpMail(String empMail) {
		this.empMail = empMail;
	}
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	public Employee(String empname, int empsal, String empadd, String empMail) {
		super();
		this.empname = empname;
		this.empsal = empsal;
		this.empadd = empadd;
		this.empMail = empMail;
	}
	@Override
	public String toString() {
		return "Employee [empname=" + empname + ", empsal=" + empsal + ", empadd=" + empadd + ", empMail=" + empMail
				+ "]";
	}
	
	
}

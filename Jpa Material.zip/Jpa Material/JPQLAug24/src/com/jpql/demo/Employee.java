package com.jpql.demo;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "empjpql")
public class Employee {

	@Id
//	@GeneratedValue(strategy = GenerationType.)
	@Column(name = "eid", length = 20)
	private int empid;
	@Column(name = "ename", length = 20)
	private String empname;
	@Column(name = "empsal", length = 20)
	private int esal;
	@Column(name = "eadd", length = 20)
	private String empadd;

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public int getEsal() {
		return esal;
	}

	public void setEsal(int esal) {
		this.esal = esal;
	}

	public String getEmpadd() {
		return empadd;
	}

	public void setEmpadd(String empadd) {
		this.empadd = empadd;
	}

	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(int empid, String empname, int esal, String empadd) {
		super();
		this.empid = empid;
		this.empname = empname;
		this.esal = esal;
		this.empadd = empadd;
	}

	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empname=" + empname + ", esal=" + esal + ", empadd=" + empadd + "]";
	}

}

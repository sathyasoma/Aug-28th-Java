package com.jpql.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Test {
	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("jpqldemo");

		EntityManager entity = factory.createEntityManager();

		entity.getTransaction().begin();

		Employee emp = new Employee(100, "reshma", 78500, "hyd");
		Employee emp1 = new Employee(108, "deepak", 18500, "kochi");
		Employee emp2 = new Employee(190, "meghana", 96452, "trvndrm");
		Employee emp3 = new Employee(560, "mokshitha", 6354, "gujrat");

	//insert-->perist(()
		
//		entity.persist(emp);
//		entity.persist(emp1);
//		entity.persist(emp2);
//		entity.persist(emp3);
		
//		TypedQuery<Employee> tq=entity.createQuery("select e from Employee e",Employee.class);
//		
//		List<Employee> li=tq.getResultList();
//		
//		for(Employee res:li)
//		{
//			System.out.println(res.getEmpadd()+" "+res.getEmpid()+"  "+res.getEmpname()
//			+" "+res.getEsal());
//		}
		
//	Query q=entity.createQuery("update Employee set esal=esal+50000 where esal>70000");
//		
//		q.executeUpdate();
		
//	Query q1=entity.createQuery("select Max(e.esal) from Employee e");
//	
//	int maxSalary=(int)q1.getSingleResult();
//	
//	System.out.println(maxSalary);
		
		Query q2=entity.createQuery("delete from Employee e where e.empid=190");
		
		q2.executeUpdate();
		
		
		
		
		entity.getTransaction().commit();

	}
}

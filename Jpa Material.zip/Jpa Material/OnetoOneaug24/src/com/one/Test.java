package com.one;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {

	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("one2one");

		EntityManager entity = factory.createEntityManager();
		
		entity.getTransaction().begin();
		
		Address ad= new Address();
		ad.setColony("saraswathi nagr");
		ad.setState("tg");
		ad.setPincode(4212244);
		
		Student st= new Student();
		st.setStname("devasena");
		st.setStmarks(68);
		st.setAddress(ad);
		
		
		entity.persist(st);//internanly addressa also persisted
		
		entity.getTransaction().commit();
	}
}

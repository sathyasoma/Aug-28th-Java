package com.one;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

@Entity
@Table(name = "one")
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int stid;
	private String stname;
	private int stmarks;

	@OneToOne
	@Cascade(CascadeType.PERSIST)
	@JoinColumn(name="st_add")
	private Address address; // has a realtion

	public int getStid() {
		return stid;
	}

	public void setStid(int stid) {
		this.stid = stid;
	}

	public String getStname() {
		return stname;
	}

	public void setStname(String stname) {
		this.stname = stname;
	}

	public int getStmarks() {
		return stmarks;
	}

	public void setStmarks(int stmarks) {
		this.stmarks = stmarks;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Student() {
		// TODO Auto-generated constructor stub
	}

	public Student(int stid, String stname, int stmarks, Address address) {
		super();
		this.stid = stid;
		this.stname = stname;
		this.stmarks = stmarks;
		this.address = address;
	}

	@Override
	public String toString() {
		return "Student [stid=" + stid + ", stname=" + stname + ", stmarks=" + stmarks + ", address=" + address + "]";
	}

}

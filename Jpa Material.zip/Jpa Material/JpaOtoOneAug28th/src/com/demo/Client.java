package com.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {
		
		EntityManagerFactory factory	=Persistence.createEntityManagerFactory("keer");
    EntityManager entity=factory.createEntityManager();
	
    entity.getTransaction().begin();
    
    Address add= new Address();
    add.setColony("sarswathi");
    add.setState("tg");
    add.setPinocde(1290);
    
    
    
    
    Employee emp= new Employee();
    emp.setEmpname("devasena");
    emp.setEmpsal(1000);
    emp.setAddress(add);
    
    entity.persist(emp);//2
    entity.getTransaction().commit();
	
	}
}

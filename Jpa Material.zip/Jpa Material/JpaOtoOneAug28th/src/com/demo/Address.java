package com.demo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Address {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int hunum;
	private String colony;
	private String state;
	private int pinocde;
	public int getHunum() {
		return hunum;
	}
	public void setHunum(int hunum) {
		this.hunum = hunum;
	}
	public String getColony() {
		return colony;
	}
	public void setColony(String colony) {
		this.colony = colony;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getPinocde() {
		return pinocde;
	}
	public void setPinocde(int pinocde) {
		this.pinocde = pinocde;
	}
	
	
	public Address() {
		// TODO Auto-generated constructor stub
	}
//	public Address(int hunum, String colony, String state, int pinocde) {
//		super();
//		this.hunum = hunum;
//		this.colony = colony;
//		this.state = state;
//		this.pinocde = pinocde;
//	}
	@Override
	public String toString() {
		return "Address [hunum=" + hunum + ", colony=" + colony + ", state=" + state + ", pinocde=" + pinocde + "]";
	}
	
}

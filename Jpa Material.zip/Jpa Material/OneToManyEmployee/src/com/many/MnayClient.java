package com.many;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class MnayClient {
public static void main(String[] args) {
	
	
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("manyUni");
	EntityManager em = factory.createEntityManager();
	em.getTransaction().begin();
	
	Department depo= new Department();
	depo.setDepid(123);
	depo.setDepname("Admin");
	
	Employees e= new Employees();
	e.setEmpadd("hyd");
	e.setEmpid(1);
	e.setEmpname("divya");
	e.setEmpsal(10000);
	
	Employees e1= new Employees();
	e1.setEmpadd("kurnool");
	e1.setEmpid(2);
	e1.setEmpname("tarun");
	e1.setEmpsal(40000);
	
	Set<Employees> emp=new HashSet();
	emp.add(e);
	emp.add(e1);
	
	depo.setEmps(emp);
	em.persist(depo);
	
	em.getTransaction().commit();
	
	
}
}

package com.many;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;

@Entity
public class Department {

	@Id
	private int depid;
	private String depname;
	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name = "depoid", referencedColumnName="depid")
	private Set<Employees> emps;

	public int getDepid() {
		return depid;
	}

	public void setDepid(int depid) {
		this.depid = depid;
	}

	public String getDepname() {
		return depname;
	}

	public void setDepname(String depname) {
		this.depname = depname;
	}

	public Set<Employees> getEmps() {
		return emps;
	}

	public void setEmps(Set<Employees> emps) {
		this.emps = emps;
	}
	
	
	
	
}

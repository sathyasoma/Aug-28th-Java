package com.demo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

@Entity
public class Student {

	@Id
	private int roolnum;
	private String name;
	private int marks;
	
	@OneToOne
	@Cascade(CascadeType.ALL)
	private Laptop laptop;//has a relation

	public int getRoolnum() {
		return roolnum;
	}

	public void setRoolnum(int roolnum) {
		this.roolnum = roolnum;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}

	public Laptop getLaptop() {
		return laptop;
	}

	public void setLaptop(Laptop laptop) {
		this.laptop = laptop;
	}


}

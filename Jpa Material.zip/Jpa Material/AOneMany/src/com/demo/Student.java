package com.demo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Student {

	@Id
	private int roolnum;
	private String name;
	private int marks;

	@OneToMany(mappedBy = "student")
	private List<Laptop> laptop = new ArrayList<Laptop>();

	public Student() {
		// TODO Auto-generated constructor stub
	}

	public Student(int roolnum, String name, int marks, List<Laptop> laptop) {
		super();
		this.roolnum = roolnum;
		this.name = name;
		this.marks = marks;
		this.laptop = laptop;
	}

	public int getRoolnum() {
		return roolnum;
	}

	public void setRoolnum(int roolnum) {
		this.roolnum = roolnum;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}

	public List<Laptop> getLaptop() {
		return laptop;
	}

	public void setLaptop(List<Laptop> laptop) {
		this.laptop = laptop;
	}

	@Override
	public String toString() {
		return "Student [roolnum=" + roolnum + ", name=" + name + ", marks=" + marks + ", laptop=" + laptop + "]";
	}

}

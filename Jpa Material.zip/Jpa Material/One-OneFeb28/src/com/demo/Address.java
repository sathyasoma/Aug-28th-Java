package com.demo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="one_address")
public class Address {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int add_id;
	private String colny;
	private String state;
	private int pincode;
	public int getAdd_id() {
		return add_id;
	}
	public void setAdd_id(int add_id) {
		this.add_id = add_id;
	}
	public String getColny() {
		return colny;
	}
	public void setColny(String colny) {
		this.colny = colny;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	
	public Address() {
		// TODO Auto-generated constructor stub
	}
	public Address(int add_id, String colny, String state, int pincode) {
		super();
		this.add_id = add_id;
		this.colny = colny;
		this.state = state;
		this.pincode = pincode;
	}
	@Override
	public String toString() {
		return "Address [add_id=" + add_id + ", colny=" + colny + ", state=" + state + ", pincode=" + pincode + "]";
	}
	
	
}

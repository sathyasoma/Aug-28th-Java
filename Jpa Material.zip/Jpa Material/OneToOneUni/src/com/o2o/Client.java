package com.o2o;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {
public static void main(String[] args) {
	
	
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("hello");
	EntityManager em = factory.createEntityManager();
	

	
    Employee emp= new Employee();
	
	emp.setEid(100);
	emp.setEname("sathya");
	
	
	Address ad=new Address();
	ad.setHuno(456);
	ad.setState("telangana");
	ad.setStreet("sateeshnagr");
	
	
	emp.setAddress(ad);
	
	em.getTransaction().begin();
	em.persist(emp);
	
	em.getTransaction().commit();
	System.out.println("one student is added");
	
	
}
}

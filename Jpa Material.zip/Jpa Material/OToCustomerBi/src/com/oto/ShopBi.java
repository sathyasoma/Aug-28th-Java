package com.oto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class ShopBi {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int shopid;
	private String shoname;
	private String shopadd;
	
	@OneToOne(mappedBy="shop")
	private CustomerBi cust;

	public int getShopid() {
		return shopid;
	}

	public void setShopid(int shopid) {
		this.shopid = shopid;
	}

	public String getShoname() {
		return shoname;
	}

	public void setShoname(String shoname) {
		this.shoname = shoname;
	}

	public String getShopadd() {
		return shopadd;
	}

	public void setShopadd(String shopadd) {
		this.shopadd = shopadd;
	}

	public CustomerBi getCust() {
		return cust;
	}

	public void setCust(CustomerBi cust) {
		this.cust = cust;
	}
	
		
	
	
}
